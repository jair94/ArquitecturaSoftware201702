/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package biblioteca.ejb;

import biblioteca.entities.Multas;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author T14750
 */
@Local
public interface MultasFacadeLocal {

    void create(Multas multas);

    void edit(Multas multas);

    void remove(Multas multas);

    Multas find(Object id);

    List<Multas> findAll();

    List<Multas> findRange(int[] range);

    int count();
    
}
