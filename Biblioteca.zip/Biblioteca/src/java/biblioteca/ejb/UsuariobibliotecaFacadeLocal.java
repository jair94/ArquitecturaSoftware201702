/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package biblioteca.ejb;

import biblioteca.entities.Usuariobiblioteca;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author T14750
 */
@Local
public interface UsuariobibliotecaFacadeLocal {

    void create(Usuariobiblioteca usuariobiblioteca);

    void edit(Usuariobiblioteca usuariobiblioteca);

    void remove(Usuariobiblioteca usuariobiblioteca);

    Usuariobiblioteca find(Object id);

    List<Usuariobiblioteca> findAll();

    List<Usuariobiblioteca> findRange(int[] range);

    int count();
    
}
