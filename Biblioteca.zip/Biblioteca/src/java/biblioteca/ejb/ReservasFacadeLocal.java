/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package biblioteca.ejb;

import biblioteca.entities.Reservas;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author T14750
 */
@Local
public interface ReservasFacadeLocal {

    void create(Reservas reservas);

    void edit(Reservas reservas);

    void remove(Reservas reservas);

    Reservas find(Object id);

    List<Reservas> findAll();

    List<Reservas> findRange(int[] range);

    int count();
    
}
