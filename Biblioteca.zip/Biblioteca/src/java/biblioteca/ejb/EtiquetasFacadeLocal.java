/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package biblioteca.ejb;

import biblioteca.entities.Etiquetas;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author T14750
 */
@Local
public interface EtiquetasFacadeLocal {

    void create(Etiquetas etiquetas);

    void edit(Etiquetas etiquetas);

    void remove(Etiquetas etiquetas);

    Etiquetas find(Object id);

    List<Etiquetas> findAll();

    List<Etiquetas> findRange(int[] range);

    int count();
    
}
