/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package biblioteca.entities;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author T14750
 */
@Entity
@Table(name = "etiquetas")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Etiquetas.findAll", query = "SELECT e FROM Etiquetas e")
    , @NamedQuery(name = "Etiquetas.findByIdEtiquetas", query = "SELECT e FROM Etiquetas e WHERE e.idEtiquetas = :idEtiquetas")
    , @NamedQuery(name = "Etiquetas.findByTipoEtiqueta", query = "SELECT e FROM Etiquetas e WHERE e.tipoEtiqueta = :tipoEtiqueta")})
public class Etiquetas implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idEtiquetas")
    private Integer idEtiquetas;
    @Size(max = 45)
    @Column(name = "Tipo_Etiqueta")
    private String tipoEtiqueta;
    @OneToMany(mappedBy = "idEtiqueta")
    private List<Items> itemsList;

    public Etiquetas() {
    }

    public Etiquetas(Integer idEtiquetas) {
        this.idEtiquetas = idEtiquetas;
    }

    public Integer getIdEtiquetas() {
        return idEtiquetas;
    }

    public void setIdEtiquetas(Integer idEtiquetas) {
        this.idEtiquetas = idEtiquetas;
    }

    public String getTipoEtiqueta() {
        return tipoEtiqueta;
    }

    public void setTipoEtiqueta(String tipoEtiqueta) {
        this.tipoEtiqueta = tipoEtiqueta;
    }

    @XmlTransient
    public List<Items> getItemsList() {
        return itemsList;
    }

    public void setItemsList(List<Items> itemsList) {
        this.itemsList = itemsList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idEtiquetas != null ? idEtiquetas.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Etiquetas)) {
            return false;
        }
        Etiquetas other = (Etiquetas) object;
        if ((this.idEtiquetas == null && other.idEtiquetas != null) || (this.idEtiquetas != null && !this.idEtiquetas.equals(other.idEtiquetas))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "biblioteca.entities.Etiquetas[ idEtiquetas=" + idEtiquetas + " ]";
    }
    
}
