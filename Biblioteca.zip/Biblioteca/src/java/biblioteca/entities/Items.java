/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package biblioteca.entities;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author T14750
 */
@Entity
@Table(name = "items")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Items.findAll", query = "SELECT i FROM Items i")
    , @NamedQuery(name = "Items.findByIdItems", query = "SELECT i FROM Items i WHERE i.idItems = :idItems")
    , @NamedQuery(name = "Items.findByTituloItem", query = "SELECT i FROM Items i WHERE i.tituloItem = :tituloItem")
    , @NamedQuery(name = "Items.findByAutor", query = "SELECT i FROM Items i WHERE i.autor = :autor")
    , @NamedQuery(name = "Items.findByEditorial", query = "SELECT i FROM Items i WHERE i.editorial = :editorial")
    , @NamedQuery(name = "Items.findByCantidadRecurso", query = "SELECT i FROM Items i WHERE i.cantidadRecurso = :cantidadRecurso")
    , @NamedQuery(name = "Items.findByCantidadRecursoDisponible", query = "SELECT i FROM Items i WHERE i.cantidadRecursoDisponible = :cantidadRecursoDisponible")
    , @NamedQuery(name = "Items.findByValorItem", query = "SELECT i FROM Items i WHERE i.valorItem = :valorItem")})
public class Items implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_Items")
    private Integer idItems;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "Titulo_Item")
    private String tituloItem;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "Autor")
    private String autor;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "Editorial")
    private String editorial;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "Cantidad_Recurso")
    private String cantidadRecurso;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "Cantidad_Recurso_Disponible")
    private String cantidadRecursoDisponible;
    @Basic(optional = false)
    @NotNull
    @Column(name = "Valor_Item")
    private double valorItem;
    @OneToMany(mappedBy = "codItem")
    private List<Prestamo> prestamoList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idItemReserva")
    private List<Reservas> reservasList;
    @JoinColumn(name = "Id_Etiqueta", referencedColumnName = "idEtiquetas")
    @ManyToOne
    private Etiquetas idEtiqueta;
    @JoinColumn(name = "id_Tipo_Item", referencedColumnName = "id_Tipo_Items")
    @ManyToOne(optional = false)
    private TipoItems idTipoItem;

    public Items() {
    }

    public Items(Integer idItems) {
        this.idItems = idItems;
    }

    public Items(Integer idItems, String tituloItem, String autor, String editorial, String cantidadRecurso, String cantidadRecursoDisponible, double valorItem) {
        this.idItems = idItems;
        this.tituloItem = tituloItem;
        this.autor = autor;
        this.editorial = editorial;
        this.cantidadRecurso = cantidadRecurso;
        this.cantidadRecursoDisponible = cantidadRecursoDisponible;
        this.valorItem = valorItem;
    }

    public Integer getIdItems() {
        return idItems;
    }

    public void setIdItems(Integer idItems) {
        this.idItems = idItems;
    }

    public String getTituloItem() {
        return tituloItem;
    }

    public void setTituloItem(String tituloItem) {
        this.tituloItem = tituloItem;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getEditorial() {
        return editorial;
    }

    public void setEditorial(String editorial) {
        this.editorial = editorial;
    }

    public String getCantidadRecurso() {
        return cantidadRecurso;
    }

    public void setCantidadRecurso(String cantidadRecurso) {
        this.cantidadRecurso = cantidadRecurso;
    }

    public String getCantidadRecursoDisponible() {
        return cantidadRecursoDisponible;
    }

    public void setCantidadRecursoDisponible(String cantidadRecursoDisponible) {
        this.cantidadRecursoDisponible = cantidadRecursoDisponible;
    }

    public double getValorItem() {
        return valorItem;
    }

    public void setValorItem(double valorItem) {
        this.valorItem = valorItem;
    }

    @XmlTransient
    public List<Prestamo> getPrestamoList() {
        return prestamoList;
    }

    public void setPrestamoList(List<Prestamo> prestamoList) {
        this.prestamoList = prestamoList;
    }

    @XmlTransient
    public List<Reservas> getReservasList() {
        return reservasList;
    }

    public void setReservasList(List<Reservas> reservasList) {
        this.reservasList = reservasList;
    }

    public Etiquetas getIdEtiqueta() {
        return idEtiqueta;
    }

    public void setIdEtiqueta(Etiquetas idEtiqueta) {
        this.idEtiqueta = idEtiqueta;
    }

    public TipoItems getIdTipoItem() {
        return idTipoItem;
    }

    public void setIdTipoItem(TipoItems idTipoItem) {
        this.idTipoItem = idTipoItem;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idItems != null ? idItems.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Items)) {
            return false;
        }
        Items other = (Items) object;
        if ((this.idItems == null && other.idItems != null) || (this.idItems != null && !this.idItems.equals(other.idItems))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "biblioteca.entities.Items[ idItems=" + idItems + " ]";
    }
    
}
