/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package biblioteca.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author T14750
 */
@Entity
@Table(name = "prestamo")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Prestamo.findAll", query = "SELECT p FROM Prestamo p")
    , @NamedQuery(name = "Prestamo.findByIdprestamo", query = "SELECT p FROM Prestamo p WHERE p.idprestamo = :idprestamo")
    , @NamedQuery(name = "Prestamo.findByFechaPrestamo", query = "SELECT p FROM Prestamo p WHERE p.fechaPrestamo = :fechaPrestamo")
    , @NamedQuery(name = "Prestamo.findByFechaPrestamoFin", query = "SELECT p FROM Prestamo p WHERE p.fechaPrestamoFin = :fechaPrestamoFin")})
public class Prestamo implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "Idprestamo")
    private Integer idprestamo;
    @Size(max = 45)
    @Column(name = "Fecha_Prestamo")
    private String fechaPrestamo;
    @Size(max = 45)
    @Column(name = "Fecha_Prestamo_Fin")
    private String fechaPrestamoFin;
    @Lob
    @Column(name = "Renovado")
    private byte[] renovado;
    @JoinColumn(name = "Cod_Item", referencedColumnName = "id_Items")
    @ManyToOne
    private Items codItem;
    @JoinColumn(name = "Tarjeta_Usuario", referencedColumnName = "Tarjeta_Biblioteca")
    @ManyToOne(optional = false)
    private Usuariobiblioteca tarjetaUsuario;

    public Prestamo() {
    }

    public Prestamo(Integer idprestamo) {
        this.idprestamo = idprestamo;
    }

    public Integer getIdprestamo() {
        return idprestamo;
    }

    public void setIdprestamo(Integer idprestamo) {
        this.idprestamo = idprestamo;
    }

    public String getFechaPrestamo() {
        return fechaPrestamo;
    }

    public void setFechaPrestamo(String fechaPrestamo) {
        this.fechaPrestamo = fechaPrestamo;
    }

    public String getFechaPrestamoFin() {
        return fechaPrestamoFin;
    }

    public void setFechaPrestamoFin(String fechaPrestamoFin) {
        this.fechaPrestamoFin = fechaPrestamoFin;
    }

    public byte[] getRenovado() {
        return renovado;
    }

    public void setRenovado(byte[] renovado) {
        this.renovado = renovado;
    }

    public Items getCodItem() {
        return codItem;
    }

    public void setCodItem(Items codItem) {
        this.codItem = codItem;
    }

    public Usuariobiblioteca getTarjetaUsuario() {
        return tarjetaUsuario;
    }

    public void setTarjetaUsuario(Usuariobiblioteca tarjetaUsuario) {
        this.tarjetaUsuario = tarjetaUsuario;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idprestamo != null ? idprestamo.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Prestamo)) {
            return false;
        }
        Prestamo other = (Prestamo) object;
        if ((this.idprestamo == null && other.idprestamo != null) || (this.idprestamo != null && !this.idprestamo.equals(other.idprestamo))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "biblioteca.entities.Prestamo[ idprestamo=" + idprestamo + " ]";
    }
    
}
