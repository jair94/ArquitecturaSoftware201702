/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package biblioteca.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

/**
 *
 * @author T14750
 */
@Embeddable
public class MultasPK implements Serializable {

    @Basic(optional = false)
    @Column(name = "idMultas")
    private int idMultas;
    @Basic(optional = false)
    @NotNull
    @Column(name = "Tarjeta_Usuario")
    private int tarjetaUsuario;

    public MultasPK() {
    }

    public MultasPK(int idMultas, int tarjetaUsuario) {
        this.idMultas = idMultas;
        this.tarjetaUsuario = tarjetaUsuario;
    }

    public int getIdMultas() {
        return idMultas;
    }

    public void setIdMultas(int idMultas) {
        this.idMultas = idMultas;
    }

    public int getTarjetaUsuario() {
        return tarjetaUsuario;
    }

    public void setTarjetaUsuario(int tarjetaUsuario) {
        this.tarjetaUsuario = tarjetaUsuario;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) idMultas;
        hash += (int) tarjetaUsuario;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof MultasPK)) {
            return false;
        }
        MultasPK other = (MultasPK) object;
        if (this.idMultas != other.idMultas) {
            return false;
        }
        if (this.tarjetaUsuario != other.tarjetaUsuario) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "biblioteca.entities.MultasPK[ idMultas=" + idMultas + ", tarjetaUsuario=" + tarjetaUsuario + " ]";
    }
    
}
