/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package biblioteca.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author T14750
 */
@Entity
@Table(name = "multas")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Multas.findAll", query = "SELECT m FROM Multas m")
    , @NamedQuery(name = "Multas.findByIdMultas", query = "SELECT m FROM Multas m WHERE m.multasPK.idMultas = :idMultas")
    , @NamedQuery(name = "Multas.findByTarjetaUsuario", query = "SELECT m FROM Multas m WHERE m.multasPK.tarjetaUsuario = :tarjetaUsuario")
    , @NamedQuery(name = "Multas.findByFechaDevoluci\u00f3n", query = "SELECT m FROM Multas m WHERE m.fechaDevoluci\u00f3n = :fechaDevoluci\u00f3n")
    , @NamedQuery(name = "Multas.findByValorMulta", query = "SELECT m FROM Multas m WHERE m.valorMulta = :valorMulta")})
public class Multas implements Serializable {

    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected MultasPK multasPK;
    @Size(max = 45)
    @Column(name = "Fecha_Devoluci\u00f3n")
    private String fechaDevolución;
    @Basic(optional = false)
    @NotNull
    @Column(name = "Valor_Multa")
    private double valorMulta;
    @Basic(optional = false)
    @NotNull
    @Lob
    @Column(name = "Estado_Multa")
    private byte[] estadoMulta;
    @JoinColumn(name = "Tarjeta_Usuario", referencedColumnName = "Tarjeta_Biblioteca", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Usuariobiblioteca usuariobiblioteca;

    public Multas() {
    }

    public Multas(MultasPK multasPK) {
        this.multasPK = multasPK;
    }

    public Multas(MultasPK multasPK, double valorMulta, byte[] estadoMulta) {
        this.multasPK = multasPK;
        this.valorMulta = valorMulta;
        this.estadoMulta = estadoMulta;
    }

    public Multas(int idMultas, int tarjetaUsuario) {
        this.multasPK = new MultasPK(idMultas, tarjetaUsuario);
    }

    public MultasPK getMultasPK() {
        return multasPK;
    }

    public void setMultasPK(MultasPK multasPK) {
        this.multasPK = multasPK;
    }

    public String getFechaDevolución() {
        return fechaDevolución;
    }

    public void setFechaDevolución(String fechaDevolución) {
        this.fechaDevolución = fechaDevolución;
    }

    public double getValorMulta() {
        return valorMulta;
    }

    public void setValorMulta(double valorMulta) {
        this.valorMulta = valorMulta;
    }

    public byte[] getEstadoMulta() {
        return estadoMulta;
    }

    public void setEstadoMulta(byte[] estadoMulta) {
        this.estadoMulta = estadoMulta;
    }

    public Usuariobiblioteca getUsuariobiblioteca() {
        return usuariobiblioteca;
    }

    public void setUsuariobiblioteca(Usuariobiblioteca usuariobiblioteca) {
        this.usuariobiblioteca = usuariobiblioteca;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (multasPK != null ? multasPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Multas)) {
            return false;
        }
        Multas other = (Multas) object;
        if ((this.multasPK == null && other.multasPK != null) || (this.multasPK != null && !this.multasPK.equals(other.multasPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "biblioteca.entities.Multas[ multasPK=" + multasPK + " ]";
    }
    
}
