/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package biblioteca.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author T14750
 */
@Entity
@Table(name = "reservas")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Reservas.findAll", query = "SELECT r FROM Reservas r")
    , @NamedQuery(name = "Reservas.findByIdReservas", query = "SELECT r FROM Reservas r WHERE r.idReservas = :idReservas")
    , @NamedQuery(name = "Reservas.findByFechaReserva", query = "SELECT r FROM Reservas r WHERE r.fechaReserva = :fechaReserva")})
public class Reservas implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idReservas")
    private Integer idReservas;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "Fecha_Reserva")
    private String fechaReserva;
    @JoinColumn(name = "Id_Estado_Reserva", referencedColumnName = "idEstados")
    @ManyToOne(optional = false)
    private Estados idEstadoReserva;
    @JoinColumn(name = "Id_Item_Reserva", referencedColumnName = "id_Items")
    @ManyToOne(optional = false)
    private Items idItemReserva;
    @JoinColumn(name = "Tarjeta_Usuario", referencedColumnName = "Tarjeta_Biblioteca")
    @ManyToOne(optional = false)
    private Usuariobiblioteca tarjetaUsuario;

    public Reservas() {
    }

    public Reservas(Integer idReservas) {
        this.idReservas = idReservas;
    }

    public Reservas(Integer idReservas, String fechaReserva) {
        this.idReservas = idReservas;
        this.fechaReserva = fechaReserva;
    }

    public Integer getIdReservas() {
        return idReservas;
    }

    public void setIdReservas(Integer idReservas) {
        this.idReservas = idReservas;
    }

    public String getFechaReserva() {
        return fechaReserva;
    }

    public void setFechaReserva(String fechaReserva) {
        this.fechaReserva = fechaReserva;
    }

    public Estados getIdEstadoReserva() {
        return idEstadoReserva;
    }

    public void setIdEstadoReserva(Estados idEstadoReserva) {
        this.idEstadoReserva = idEstadoReserva;
    }

    public Items getIdItemReserva() {
        return idItemReserva;
    }

    public void setIdItemReserva(Items idItemReserva) {
        this.idItemReserva = idItemReserva;
    }

    public Usuariobiblioteca getTarjetaUsuario() {
        return tarjetaUsuario;
    }

    public void setTarjetaUsuario(Usuariobiblioteca tarjetaUsuario) {
        this.tarjetaUsuario = tarjetaUsuario;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idReservas != null ? idReservas.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Reservas)) {
            return false;
        }
        Reservas other = (Reservas) object;
        if ((this.idReservas == null && other.idReservas != null) || (this.idReservas != null && !this.idReservas.equals(other.idReservas))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "biblioteca.entities.Reservas[ idReservas=" + idReservas + " ]";
    }
    
}
