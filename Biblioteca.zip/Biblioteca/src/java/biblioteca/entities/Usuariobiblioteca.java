/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package biblioteca.entities;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author T14750
 */
@Entity
@Table(name = "usuariobiblioteca")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Usuariobiblioteca.findAll", query = "SELECT u FROM Usuariobiblioteca u")
    , @NamedQuery(name = "Usuariobiblioteca.findByTarjetaBiblioteca", query = "SELECT u FROM Usuariobiblioteca u WHERE u.tarjetaBiblioteca = :tarjetaBiblioteca")
    , @NamedQuery(name = "Usuariobiblioteca.findByNombreUsuario", query = "SELECT u FROM Usuariobiblioteca u WHERE u.nombreUsuario = :nombreUsuario")
    , @NamedQuery(name = "Usuariobiblioteca.findByApellidoUsuario", query = "SELECT u FROM Usuariobiblioteca u WHERE u.apellidoUsuario = :apellidoUsuario")
    , @NamedQuery(name = "Usuariobiblioteca.findByNumTelefono", query = "SELECT u FROM Usuariobiblioteca u WHERE u.numTelefono = :numTelefono")
    , @NamedQuery(name = "Usuariobiblioteca.findByFechaNacimiento", query = "SELECT u FROM Usuariobiblioteca u WHERE u.fechaNacimiento = :fechaNacimiento")
    , @NamedQuery(name = "Usuariobiblioteca.findByFechaRegistro", query = "SELECT u FROM Usuariobiblioteca u WHERE u.fechaRegistro = :fechaRegistro")
    , @NamedQuery(name = "Usuariobiblioteca.findByFechaRetiro", query = "SELECT u FROM Usuariobiblioteca u WHERE u.fechaRetiro = :fechaRetiro")})
public class Usuariobiblioteca implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "Tarjeta_Biblioteca")
    private Integer tarjetaBiblioteca;
    @Size(max = 45)
    @Column(name = "Nombre_Usuario")
    private String nombreUsuario;
    @Size(max = 45)
    @Column(name = "Apellido_Usuario")
    private String apellidoUsuario;
    @Size(max = 45)
    @Column(name = "Num_Telefono")
    private String numTelefono;
    @Size(max = 45)
    @Column(name = "Fecha_Nacimiento")
    private String fechaNacimiento;
    @Size(max = 45)
    @Column(name = "Fecha_Registro")
    private String fechaRegistro;
    @Size(max = 45)
    @Column(name = "Fecha_Retiro")
    private String fechaRetiro;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "usuariobiblioteca")
    private List<Multas> multasList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "tarjetaUsuario")
    private List<Prestamo> prestamoList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "tarjetaUsuario")
    private List<Reservas> reservasList;

    public Usuariobiblioteca() {
    }

    public Usuariobiblioteca(Integer tarjetaBiblioteca) {
        this.tarjetaBiblioteca = tarjetaBiblioteca;
    }

    public Integer getTarjetaBiblioteca() {
        return tarjetaBiblioteca;
    }

    public void setTarjetaBiblioteca(Integer tarjetaBiblioteca) {
        this.tarjetaBiblioteca = tarjetaBiblioteca;
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario;
    }

    public String getApellidoUsuario() {
        return apellidoUsuario;
    }

    public void setApellidoUsuario(String apellidoUsuario) {
        this.apellidoUsuario = apellidoUsuario;
    }

    public String getNumTelefono() {
        return numTelefono;
    }

    public void setNumTelefono(String numTelefono) {
        this.numTelefono = numTelefono;
    }

    public String getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(String fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public String getFechaRegistro() {
        return fechaRegistro;
    }

    public void setFechaRegistro(String fechaRegistro) {
        this.fechaRegistro = fechaRegistro;
    }

    public String getFechaRetiro() {
        return fechaRetiro;
    }

    public void setFechaRetiro(String fechaRetiro) {
        this.fechaRetiro = fechaRetiro;
    }

    @XmlTransient
    public List<Multas> getMultasList() {
        return multasList;
    }

    public void setMultasList(List<Multas> multasList) {
        this.multasList = multasList;
    }

    @XmlTransient
    public List<Prestamo> getPrestamoList() {
        return prestamoList;
    }

    public void setPrestamoList(List<Prestamo> prestamoList) {
        this.prestamoList = prestamoList;
    }

    @XmlTransient
    public List<Reservas> getReservasList() {
        return reservasList;
    }

    public void setReservasList(List<Reservas> reservasList) {
        this.reservasList = reservasList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (tarjetaBiblioteca != null ? tarjetaBiblioteca.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Usuariobiblioteca)) {
            return false;
        }
        Usuariobiblioteca other = (Usuariobiblioteca) object;
        if ((this.tarjetaBiblioteca == null && other.tarjetaBiblioteca != null) || (this.tarjetaBiblioteca != null && !this.tarjetaBiblioteca.equals(other.tarjetaBiblioteca))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "biblioteca.entities.Usuariobiblioteca[ tarjetaBiblioteca=" + tarjetaBiblioteca + " ]";
    }
    
}
