/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package biblioteca.Beans;

import biblioteca.Beans.exceptions.NonexistentEntityException;
import biblioteca.Beans.exceptions.RollbackFailureException;
import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import biblioteca.entities.Estados;
import biblioteca.entities.Items;
import biblioteca.entities.Reservas;
import biblioteca.entities.Usuariobiblioteca;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.transaction.UserTransaction;

/**
 *
 * @author T14750
 */
public class ReservasJpaController implements Serializable {

    public ReservasJpaController(UserTransaction utx, EntityManagerFactory emf) {
        this.utx = utx;
        this.emf = emf;
    }
    private UserTransaction utx = null;
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Reservas reservas) throws RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Estados idEstadoReserva = reservas.getIdEstadoReserva();
            if (idEstadoReserva != null) {
                idEstadoReserva = em.getReference(idEstadoReserva.getClass(), idEstadoReserva.getIdEstados());
                reservas.setIdEstadoReserva(idEstadoReserva);
            }
            Items idItemReserva = reservas.getIdItemReserva();
            if (idItemReserva != null) {
                idItemReserva = em.getReference(idItemReserva.getClass(), idItemReserva.getIdItems());
                reservas.setIdItemReserva(idItemReserva);
            }
            Usuariobiblioteca tarjetaUsuario = reservas.getTarjetaUsuario();
            if (tarjetaUsuario != null) {
                tarjetaUsuario = em.getReference(tarjetaUsuario.getClass(), tarjetaUsuario.getTarjetaBiblioteca());
                reservas.setTarjetaUsuario(tarjetaUsuario);
            }
            em.persist(reservas);
            if (idEstadoReserva != null) {
                idEstadoReserva.getReservasList().add(reservas);
                idEstadoReserva = em.merge(idEstadoReserva);
            }
            if (idItemReserva != null) {
                idItemReserva.getReservasList().add(reservas);
                idItemReserva = em.merge(idItemReserva);
            }
            if (tarjetaUsuario != null) {
                tarjetaUsuario.getReservasList().add(reservas);
                tarjetaUsuario = em.merge(tarjetaUsuario);
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Reservas reservas) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Reservas persistentReservas = em.find(Reservas.class, reservas.getIdReservas());
            Estados idEstadoReservaOld = persistentReservas.getIdEstadoReserva();
            Estados idEstadoReservaNew = reservas.getIdEstadoReserva();
            Items idItemReservaOld = persistentReservas.getIdItemReserva();
            Items idItemReservaNew = reservas.getIdItemReserva();
            Usuariobiblioteca tarjetaUsuarioOld = persistentReservas.getTarjetaUsuario();
            Usuariobiblioteca tarjetaUsuarioNew = reservas.getTarjetaUsuario();
            if (idEstadoReservaNew != null) {
                idEstadoReservaNew = em.getReference(idEstadoReservaNew.getClass(), idEstadoReservaNew.getIdEstados());
                reservas.setIdEstadoReserva(idEstadoReservaNew);
            }
            if (idItemReservaNew != null) {
                idItemReservaNew = em.getReference(idItemReservaNew.getClass(), idItemReservaNew.getIdItems());
                reservas.setIdItemReserva(idItemReservaNew);
            }
            if (tarjetaUsuarioNew != null) {
                tarjetaUsuarioNew = em.getReference(tarjetaUsuarioNew.getClass(), tarjetaUsuarioNew.getTarjetaBiblioteca());
                reservas.setTarjetaUsuario(tarjetaUsuarioNew);
            }
            reservas = em.merge(reservas);
            if (idEstadoReservaOld != null && !idEstadoReservaOld.equals(idEstadoReservaNew)) {
                idEstadoReservaOld.getReservasList().remove(reservas);
                idEstadoReservaOld = em.merge(idEstadoReservaOld);
            }
            if (idEstadoReservaNew != null && !idEstadoReservaNew.equals(idEstadoReservaOld)) {
                idEstadoReservaNew.getReservasList().add(reservas);
                idEstadoReservaNew = em.merge(idEstadoReservaNew);
            }
            if (idItemReservaOld != null && !idItemReservaOld.equals(idItemReservaNew)) {
                idItemReservaOld.getReservasList().remove(reservas);
                idItemReservaOld = em.merge(idItemReservaOld);
            }
            if (idItemReservaNew != null && !idItemReservaNew.equals(idItemReservaOld)) {
                idItemReservaNew.getReservasList().add(reservas);
                idItemReservaNew = em.merge(idItemReservaNew);
            }
            if (tarjetaUsuarioOld != null && !tarjetaUsuarioOld.equals(tarjetaUsuarioNew)) {
                tarjetaUsuarioOld.getReservasList().remove(reservas);
                tarjetaUsuarioOld = em.merge(tarjetaUsuarioOld);
            }
            if (tarjetaUsuarioNew != null && !tarjetaUsuarioNew.equals(tarjetaUsuarioOld)) {
                tarjetaUsuarioNew.getReservasList().add(reservas);
                tarjetaUsuarioNew = em.merge(tarjetaUsuarioNew);
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = reservas.getIdReservas();
                if (findReservas(id) == null) {
                    throw new NonexistentEntityException("The reservas with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Reservas reservas;
            try {
                reservas = em.getReference(Reservas.class, id);
                reservas.getIdReservas();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The reservas with id " + id + " no longer exists.", enfe);
            }
            Estados idEstadoReserva = reservas.getIdEstadoReserva();
            if (idEstadoReserva != null) {
                idEstadoReserva.getReservasList().remove(reservas);
                idEstadoReserva = em.merge(idEstadoReserva);
            }
            Items idItemReserva = reservas.getIdItemReserva();
            if (idItemReserva != null) {
                idItemReserva.getReservasList().remove(reservas);
                idItemReserva = em.merge(idItemReserva);
            }
            Usuariobiblioteca tarjetaUsuario = reservas.getTarjetaUsuario();
            if (tarjetaUsuario != null) {
                tarjetaUsuario.getReservasList().remove(reservas);
                tarjetaUsuario = em.merge(tarjetaUsuario);
            }
            em.remove(reservas);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Reservas> findReservasEntities() {
        return findReservasEntities(true, -1, -1);
    }

    public List<Reservas> findReservasEntities(int maxResults, int firstResult) {
        return findReservasEntities(false, maxResults, firstResult);
    }

    private List<Reservas> findReservasEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Reservas.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Reservas findReservas(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Reservas.class, id);
        } finally {
            em.close();
        }
    }

    public int getReservasCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Reservas> rt = cq.from(Reservas.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
