/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package biblioteca.Beans;

import biblioteca.Beans.exceptions.NonexistentEntityException;
import biblioteca.Beans.exceptions.PreexistingEntityException;
import biblioteca.Beans.exceptions.RollbackFailureException;
import biblioteca.entities.Multas;
import biblioteca.entities.MultasPK;
import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import biblioteca.entities.Usuariobiblioteca;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.transaction.UserTransaction;

/**
 *
 * @author T14750
 */
public class MultasJpaController implements Serializable {

    public MultasJpaController(UserTransaction utx, EntityManagerFactory emf) {
        this.utx = utx;
        this.emf = emf;
    }
    private UserTransaction utx = null;
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Multas multas) throws PreexistingEntityException, RollbackFailureException, Exception {
        if (multas.getMultasPK() == null) {
            multas.setMultasPK(new MultasPK());
        }
        multas.getMultasPK().setTarjetaUsuario(multas.getUsuariobiblioteca().getTarjetaBiblioteca());
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Usuariobiblioteca usuariobiblioteca = multas.getUsuariobiblioteca();
            if (usuariobiblioteca != null) {
                usuariobiblioteca = em.getReference(usuariobiblioteca.getClass(), usuariobiblioteca.getTarjetaBiblioteca());
                multas.setUsuariobiblioteca(usuariobiblioteca);
            }
            em.persist(multas);
            if (usuariobiblioteca != null) {
                usuariobiblioteca.getMultasList().add(multas);
                usuariobiblioteca = em.merge(usuariobiblioteca);
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            if (findMultas(multas.getMultasPK()) != null) {
                throw new PreexistingEntityException("Multas " + multas + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Multas multas) throws NonexistentEntityException, RollbackFailureException, Exception {
        multas.getMultasPK().setTarjetaUsuario(multas.getUsuariobiblioteca().getTarjetaBiblioteca());
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Multas persistentMultas = em.find(Multas.class, multas.getMultasPK());
            Usuariobiblioteca usuariobibliotecaOld = persistentMultas.getUsuariobiblioteca();
            Usuariobiblioteca usuariobibliotecaNew = multas.getUsuariobiblioteca();
            if (usuariobibliotecaNew != null) {
                usuariobibliotecaNew = em.getReference(usuariobibliotecaNew.getClass(), usuariobibliotecaNew.getTarjetaBiblioteca());
                multas.setUsuariobiblioteca(usuariobibliotecaNew);
            }
            multas = em.merge(multas);
            if (usuariobibliotecaOld != null && !usuariobibliotecaOld.equals(usuariobibliotecaNew)) {
                usuariobibliotecaOld.getMultasList().remove(multas);
                usuariobibliotecaOld = em.merge(usuariobibliotecaOld);
            }
            if (usuariobibliotecaNew != null && !usuariobibliotecaNew.equals(usuariobibliotecaOld)) {
                usuariobibliotecaNew.getMultasList().add(multas);
                usuariobibliotecaNew = em.merge(usuariobibliotecaNew);
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                MultasPK id = multas.getMultasPK();
                if (findMultas(id) == null) {
                    throw new NonexistentEntityException("The multas with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(MultasPK id) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Multas multas;
            try {
                multas = em.getReference(Multas.class, id);
                multas.getMultasPK();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The multas with id " + id + " no longer exists.", enfe);
            }
            Usuariobiblioteca usuariobiblioteca = multas.getUsuariobiblioteca();
            if (usuariobiblioteca != null) {
                usuariobiblioteca.getMultasList().remove(multas);
                usuariobiblioteca = em.merge(usuariobiblioteca);
            }
            em.remove(multas);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Multas> findMultasEntities() {
        return findMultasEntities(true, -1, -1);
    }

    public List<Multas> findMultasEntities(int maxResults, int firstResult) {
        return findMultasEntities(false, maxResults, firstResult);
    }

    private List<Multas> findMultasEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Multas.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Multas findMultas(MultasPK id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Multas.class, id);
        } finally {
            em.close();
        }
    }

    public int getMultasCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Multas> rt = cq.from(Multas.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
