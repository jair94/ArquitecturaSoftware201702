/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package biblioteca.Beans;

import biblioteca.Beans.exceptions.NonexistentEntityException;
import biblioteca.Beans.exceptions.RollbackFailureException;
import biblioteca.entities.Etiquetas;
import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import biblioteca.entities.Items;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.transaction.UserTransaction;

/**
 *
 * @author T14750
 */
public class EtiquetasJpaController implements Serializable {

    public EtiquetasJpaController(UserTransaction utx, EntityManagerFactory emf) {
        this.utx = utx;
        this.emf = emf;
    }
    private UserTransaction utx = null;
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Etiquetas etiquetas) throws RollbackFailureException, Exception {
        if (etiquetas.getItemsList() == null) {
            etiquetas.setItemsList(new ArrayList<Items>());
        }
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            List<Items> attachedItemsList = new ArrayList<Items>();
            for (Items itemsListItemsToAttach : etiquetas.getItemsList()) {
                itemsListItemsToAttach = em.getReference(itemsListItemsToAttach.getClass(), itemsListItemsToAttach.getIdItems());
                attachedItemsList.add(itemsListItemsToAttach);
            }
            etiquetas.setItemsList(attachedItemsList);
            em.persist(etiquetas);
            for (Items itemsListItems : etiquetas.getItemsList()) {
                Etiquetas oldIdEtiquetaOfItemsListItems = itemsListItems.getIdEtiqueta();
                itemsListItems.setIdEtiqueta(etiquetas);
                itemsListItems = em.merge(itemsListItems);
                if (oldIdEtiquetaOfItemsListItems != null) {
                    oldIdEtiquetaOfItemsListItems.getItemsList().remove(itemsListItems);
                    oldIdEtiquetaOfItemsListItems = em.merge(oldIdEtiquetaOfItemsListItems);
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Etiquetas etiquetas) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Etiquetas persistentEtiquetas = em.find(Etiquetas.class, etiquetas.getIdEtiquetas());
            List<Items> itemsListOld = persistentEtiquetas.getItemsList();
            List<Items> itemsListNew = etiquetas.getItemsList();
            List<Items> attachedItemsListNew = new ArrayList<Items>();
            for (Items itemsListNewItemsToAttach : itemsListNew) {
                itemsListNewItemsToAttach = em.getReference(itemsListNewItemsToAttach.getClass(), itemsListNewItemsToAttach.getIdItems());
                attachedItemsListNew.add(itemsListNewItemsToAttach);
            }
            itemsListNew = attachedItemsListNew;
            etiquetas.setItemsList(itemsListNew);
            etiquetas = em.merge(etiquetas);
            for (Items itemsListOldItems : itemsListOld) {
                if (!itemsListNew.contains(itemsListOldItems)) {
                    itemsListOldItems.setIdEtiqueta(null);
                    itemsListOldItems = em.merge(itemsListOldItems);
                }
            }
            for (Items itemsListNewItems : itemsListNew) {
                if (!itemsListOld.contains(itemsListNewItems)) {
                    Etiquetas oldIdEtiquetaOfItemsListNewItems = itemsListNewItems.getIdEtiqueta();
                    itemsListNewItems.setIdEtiqueta(etiquetas);
                    itemsListNewItems = em.merge(itemsListNewItems);
                    if (oldIdEtiquetaOfItemsListNewItems != null && !oldIdEtiquetaOfItemsListNewItems.equals(etiquetas)) {
                        oldIdEtiquetaOfItemsListNewItems.getItemsList().remove(itemsListNewItems);
                        oldIdEtiquetaOfItemsListNewItems = em.merge(oldIdEtiquetaOfItemsListNewItems);
                    }
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = etiquetas.getIdEtiquetas();
                if (findEtiquetas(id) == null) {
                    throw new NonexistentEntityException("The etiquetas with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Etiquetas etiquetas;
            try {
                etiquetas = em.getReference(Etiquetas.class, id);
                etiquetas.getIdEtiquetas();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The etiquetas with id " + id + " no longer exists.", enfe);
            }
            List<Items> itemsList = etiquetas.getItemsList();
            for (Items itemsListItems : itemsList) {
                itemsListItems.setIdEtiqueta(null);
                itemsListItems = em.merge(itemsListItems);
            }
            em.remove(etiquetas);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Etiquetas> findEtiquetasEntities() {
        return findEtiquetasEntities(true, -1, -1);
    }

    public List<Etiquetas> findEtiquetasEntities(int maxResults, int firstResult) {
        return findEtiquetasEntities(false, maxResults, firstResult);
    }

    private List<Etiquetas> findEtiquetasEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Etiquetas.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Etiquetas findEtiquetas(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Etiquetas.class, id);
        } finally {
            em.close();
        }
    }

    public int getEtiquetasCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Etiquetas> rt = cq.from(Etiquetas.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
