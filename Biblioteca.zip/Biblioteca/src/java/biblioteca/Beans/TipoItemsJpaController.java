/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package biblioteca.Beans;

import biblioteca.Beans.exceptions.IllegalOrphanException;
import biblioteca.Beans.exceptions.NonexistentEntityException;
import biblioteca.Beans.exceptions.RollbackFailureException;
import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import biblioteca.entities.Items;
import biblioteca.entities.TipoItems;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.transaction.UserTransaction;

/**
 *
 * @author T14750
 */
public class TipoItemsJpaController implements Serializable {

    public TipoItemsJpaController(UserTransaction utx, EntityManagerFactory emf) {
        this.utx = utx;
        this.emf = emf;
    }
    private UserTransaction utx = null;
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(TipoItems tipoItems) throws RollbackFailureException, Exception {
        if (tipoItems.getItemsList() == null) {
            tipoItems.setItemsList(new ArrayList<Items>());
        }
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            List<Items> attachedItemsList = new ArrayList<Items>();
            for (Items itemsListItemsToAttach : tipoItems.getItemsList()) {
                itemsListItemsToAttach = em.getReference(itemsListItemsToAttach.getClass(), itemsListItemsToAttach.getIdItems());
                attachedItemsList.add(itemsListItemsToAttach);
            }
            tipoItems.setItemsList(attachedItemsList);
            em.persist(tipoItems);
            for (Items itemsListItems : tipoItems.getItemsList()) {
                TipoItems oldIdTipoItemOfItemsListItems = itemsListItems.getIdTipoItem();
                itemsListItems.setIdTipoItem(tipoItems);
                itemsListItems = em.merge(itemsListItems);
                if (oldIdTipoItemOfItemsListItems != null) {
                    oldIdTipoItemOfItemsListItems.getItemsList().remove(itemsListItems);
                    oldIdTipoItemOfItemsListItems = em.merge(oldIdTipoItemOfItemsListItems);
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(TipoItems tipoItems) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            TipoItems persistentTipoItems = em.find(TipoItems.class, tipoItems.getIdTipoItems());
            List<Items> itemsListOld = persistentTipoItems.getItemsList();
            List<Items> itemsListNew = tipoItems.getItemsList();
            List<String> illegalOrphanMessages = null;
            for (Items itemsListOldItems : itemsListOld) {
                if (!itemsListNew.contains(itemsListOldItems)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain Items " + itemsListOldItems + " since its idTipoItem field is not nullable.");
                }
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            List<Items> attachedItemsListNew = new ArrayList<Items>();
            for (Items itemsListNewItemsToAttach : itemsListNew) {
                itemsListNewItemsToAttach = em.getReference(itemsListNewItemsToAttach.getClass(), itemsListNewItemsToAttach.getIdItems());
                attachedItemsListNew.add(itemsListNewItemsToAttach);
            }
            itemsListNew = attachedItemsListNew;
            tipoItems.setItemsList(itemsListNew);
            tipoItems = em.merge(tipoItems);
            for (Items itemsListNewItems : itemsListNew) {
                if (!itemsListOld.contains(itemsListNewItems)) {
                    TipoItems oldIdTipoItemOfItemsListNewItems = itemsListNewItems.getIdTipoItem();
                    itemsListNewItems.setIdTipoItem(tipoItems);
                    itemsListNewItems = em.merge(itemsListNewItems);
                    if (oldIdTipoItemOfItemsListNewItems != null && !oldIdTipoItemOfItemsListNewItems.equals(tipoItems)) {
                        oldIdTipoItemOfItemsListNewItems.getItemsList().remove(itemsListNewItems);
                        oldIdTipoItemOfItemsListNewItems = em.merge(oldIdTipoItemOfItemsListNewItems);
                    }
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = tipoItems.getIdTipoItems();
                if (findTipoItems(id) == null) {
                    throw new NonexistentEntityException("The tipoItems with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            TipoItems tipoItems;
            try {
                tipoItems = em.getReference(TipoItems.class, id);
                tipoItems.getIdTipoItems();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The tipoItems with id " + id + " no longer exists.", enfe);
            }
            List<String> illegalOrphanMessages = null;
            List<Items> itemsListOrphanCheck = tipoItems.getItemsList();
            for (Items itemsListOrphanCheckItems : itemsListOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This TipoItems (" + tipoItems + ") cannot be destroyed since the Items " + itemsListOrphanCheckItems + " in its itemsList field has a non-nullable idTipoItem field.");
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            em.remove(tipoItems);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<TipoItems> findTipoItemsEntities() {
        return findTipoItemsEntities(true, -1, -1);
    }

    public List<TipoItems> findTipoItemsEntities(int maxResults, int firstResult) {
        return findTipoItemsEntities(false, maxResults, firstResult);
    }

    private List<TipoItems> findTipoItemsEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(TipoItems.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public TipoItems findTipoItems(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(TipoItems.class, id);
        } finally {
            em.close();
        }
    }

    public int getTipoItemsCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<TipoItems> rt = cq.from(TipoItems.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
