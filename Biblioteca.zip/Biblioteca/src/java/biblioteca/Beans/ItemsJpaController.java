/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package biblioteca.Beans;

import biblioteca.Beans.exceptions.IllegalOrphanException;
import biblioteca.Beans.exceptions.NonexistentEntityException;
import biblioteca.Beans.exceptions.RollbackFailureException;
import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import biblioteca.entities.Etiquetas;
import biblioteca.entities.Items;
import biblioteca.entities.TipoItems;
import biblioteca.entities.Prestamo;
import java.util.ArrayList;
import java.util.List;
import biblioteca.entities.Reservas;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.transaction.UserTransaction;

/**
 *
 * @author T14750
 */
public class ItemsJpaController implements Serializable {

    public ItemsJpaController(UserTransaction utx, EntityManagerFactory emf) {
        this.utx = utx;
        this.emf = emf;
    }
    private UserTransaction utx = null;
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Items items) throws RollbackFailureException, Exception {
        if (items.getPrestamoList() == null) {
            items.setPrestamoList(new ArrayList<Prestamo>());
        }
        if (items.getReservasList() == null) {
            items.setReservasList(new ArrayList<Reservas>());
        }
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Etiquetas idEtiqueta = items.getIdEtiqueta();
            if (idEtiqueta != null) {
                idEtiqueta = em.getReference(idEtiqueta.getClass(), idEtiqueta.getIdEtiquetas());
                items.setIdEtiqueta(idEtiqueta);
            }
            TipoItems idTipoItem = items.getIdTipoItem();
            if (idTipoItem != null) {
                idTipoItem = em.getReference(idTipoItem.getClass(), idTipoItem.getIdTipoItems());
                items.setIdTipoItem(idTipoItem);
            }
            List<Prestamo> attachedPrestamoList = new ArrayList<Prestamo>();
            for (Prestamo prestamoListPrestamoToAttach : items.getPrestamoList()) {
                prestamoListPrestamoToAttach = em.getReference(prestamoListPrestamoToAttach.getClass(), prestamoListPrestamoToAttach.getIdprestamo());
                attachedPrestamoList.add(prestamoListPrestamoToAttach);
            }
            items.setPrestamoList(attachedPrestamoList);
            List<Reservas> attachedReservasList = new ArrayList<Reservas>();
            for (Reservas reservasListReservasToAttach : items.getReservasList()) {
                reservasListReservasToAttach = em.getReference(reservasListReservasToAttach.getClass(), reservasListReservasToAttach.getIdReservas());
                attachedReservasList.add(reservasListReservasToAttach);
            }
            items.setReservasList(attachedReservasList);
            em.persist(items);
            if (idEtiqueta != null) {
                idEtiqueta.getItemsList().add(items);
                idEtiqueta = em.merge(idEtiqueta);
            }
            if (idTipoItem != null) {
                idTipoItem.getItemsList().add(items);
                idTipoItem = em.merge(idTipoItem);
            }
            for (Prestamo prestamoListPrestamo : items.getPrestamoList()) {
                Items oldCodItemOfPrestamoListPrestamo = prestamoListPrestamo.getCodItem();
                prestamoListPrestamo.setCodItem(items);
                prestamoListPrestamo = em.merge(prestamoListPrestamo);
                if (oldCodItemOfPrestamoListPrestamo != null) {
                    oldCodItemOfPrestamoListPrestamo.getPrestamoList().remove(prestamoListPrestamo);
                    oldCodItemOfPrestamoListPrestamo = em.merge(oldCodItemOfPrestamoListPrestamo);
                }
            }
            for (Reservas reservasListReservas : items.getReservasList()) {
                Items oldIdItemReservaOfReservasListReservas = reservasListReservas.getIdItemReserva();
                reservasListReservas.setIdItemReserva(items);
                reservasListReservas = em.merge(reservasListReservas);
                if (oldIdItemReservaOfReservasListReservas != null) {
                    oldIdItemReservaOfReservasListReservas.getReservasList().remove(reservasListReservas);
                    oldIdItemReservaOfReservasListReservas = em.merge(oldIdItemReservaOfReservasListReservas);
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Items items) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Items persistentItems = em.find(Items.class, items.getIdItems());
            Etiquetas idEtiquetaOld = persistentItems.getIdEtiqueta();
            Etiquetas idEtiquetaNew = items.getIdEtiqueta();
            TipoItems idTipoItemOld = persistentItems.getIdTipoItem();
            TipoItems idTipoItemNew = items.getIdTipoItem();
            List<Prestamo> prestamoListOld = persistentItems.getPrestamoList();
            List<Prestamo> prestamoListNew = items.getPrestamoList();
            List<Reservas> reservasListOld = persistentItems.getReservasList();
            List<Reservas> reservasListNew = items.getReservasList();
            List<String> illegalOrphanMessages = null;
            for (Reservas reservasListOldReservas : reservasListOld) {
                if (!reservasListNew.contains(reservasListOldReservas)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain Reservas " + reservasListOldReservas + " since its idItemReserva field is not nullable.");
                }
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            if (idEtiquetaNew != null) {
                idEtiquetaNew = em.getReference(idEtiquetaNew.getClass(), idEtiquetaNew.getIdEtiquetas());
                items.setIdEtiqueta(idEtiquetaNew);
            }
            if (idTipoItemNew != null) {
                idTipoItemNew = em.getReference(idTipoItemNew.getClass(), idTipoItemNew.getIdTipoItems());
                items.setIdTipoItem(idTipoItemNew);
            }
            List<Prestamo> attachedPrestamoListNew = new ArrayList<Prestamo>();
            for (Prestamo prestamoListNewPrestamoToAttach : prestamoListNew) {
                prestamoListNewPrestamoToAttach = em.getReference(prestamoListNewPrestamoToAttach.getClass(), prestamoListNewPrestamoToAttach.getIdprestamo());
                attachedPrestamoListNew.add(prestamoListNewPrestamoToAttach);
            }
            prestamoListNew = attachedPrestamoListNew;
            items.setPrestamoList(prestamoListNew);
            List<Reservas> attachedReservasListNew = new ArrayList<Reservas>();
            for (Reservas reservasListNewReservasToAttach : reservasListNew) {
                reservasListNewReservasToAttach = em.getReference(reservasListNewReservasToAttach.getClass(), reservasListNewReservasToAttach.getIdReservas());
                attachedReservasListNew.add(reservasListNewReservasToAttach);
            }
            reservasListNew = attachedReservasListNew;
            items.setReservasList(reservasListNew);
            items = em.merge(items);
            if (idEtiquetaOld != null && !idEtiquetaOld.equals(idEtiquetaNew)) {
                idEtiquetaOld.getItemsList().remove(items);
                idEtiquetaOld = em.merge(idEtiquetaOld);
            }
            if (idEtiquetaNew != null && !idEtiquetaNew.equals(idEtiquetaOld)) {
                idEtiquetaNew.getItemsList().add(items);
                idEtiquetaNew = em.merge(idEtiquetaNew);
            }
            if (idTipoItemOld != null && !idTipoItemOld.equals(idTipoItemNew)) {
                idTipoItemOld.getItemsList().remove(items);
                idTipoItemOld = em.merge(idTipoItemOld);
            }
            if (idTipoItemNew != null && !idTipoItemNew.equals(idTipoItemOld)) {
                idTipoItemNew.getItemsList().add(items);
                idTipoItemNew = em.merge(idTipoItemNew);
            }
            for (Prestamo prestamoListOldPrestamo : prestamoListOld) {
                if (!prestamoListNew.contains(prestamoListOldPrestamo)) {
                    prestamoListOldPrestamo.setCodItem(null);
                    prestamoListOldPrestamo = em.merge(prestamoListOldPrestamo);
                }
            }
            for (Prestamo prestamoListNewPrestamo : prestamoListNew) {
                if (!prestamoListOld.contains(prestamoListNewPrestamo)) {
                    Items oldCodItemOfPrestamoListNewPrestamo = prestamoListNewPrestamo.getCodItem();
                    prestamoListNewPrestamo.setCodItem(items);
                    prestamoListNewPrestamo = em.merge(prestamoListNewPrestamo);
                    if (oldCodItemOfPrestamoListNewPrestamo != null && !oldCodItemOfPrestamoListNewPrestamo.equals(items)) {
                        oldCodItemOfPrestamoListNewPrestamo.getPrestamoList().remove(prestamoListNewPrestamo);
                        oldCodItemOfPrestamoListNewPrestamo = em.merge(oldCodItemOfPrestamoListNewPrestamo);
                    }
                }
            }
            for (Reservas reservasListNewReservas : reservasListNew) {
                if (!reservasListOld.contains(reservasListNewReservas)) {
                    Items oldIdItemReservaOfReservasListNewReservas = reservasListNewReservas.getIdItemReserva();
                    reservasListNewReservas.setIdItemReserva(items);
                    reservasListNewReservas = em.merge(reservasListNewReservas);
                    if (oldIdItemReservaOfReservasListNewReservas != null && !oldIdItemReservaOfReservasListNewReservas.equals(items)) {
                        oldIdItemReservaOfReservasListNewReservas.getReservasList().remove(reservasListNewReservas);
                        oldIdItemReservaOfReservasListNewReservas = em.merge(oldIdItemReservaOfReservasListNewReservas);
                    }
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = items.getIdItems();
                if (findItems(id) == null) {
                    throw new NonexistentEntityException("The items with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Items items;
            try {
                items = em.getReference(Items.class, id);
                items.getIdItems();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The items with id " + id + " no longer exists.", enfe);
            }
            List<String> illegalOrphanMessages = null;
            List<Reservas> reservasListOrphanCheck = items.getReservasList();
            for (Reservas reservasListOrphanCheckReservas : reservasListOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Items (" + items + ") cannot be destroyed since the Reservas " + reservasListOrphanCheckReservas + " in its reservasList field has a non-nullable idItemReserva field.");
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            Etiquetas idEtiqueta = items.getIdEtiqueta();
            if (idEtiqueta != null) {
                idEtiqueta.getItemsList().remove(items);
                idEtiqueta = em.merge(idEtiqueta);
            }
            TipoItems idTipoItem = items.getIdTipoItem();
            if (idTipoItem != null) {
                idTipoItem.getItemsList().remove(items);
                idTipoItem = em.merge(idTipoItem);
            }
            List<Prestamo> prestamoList = items.getPrestamoList();
            for (Prestamo prestamoListPrestamo : prestamoList) {
                prestamoListPrestamo.setCodItem(null);
                prestamoListPrestamo = em.merge(prestamoListPrestamo);
            }
            em.remove(items);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Items> findItemsEntities() {
        return findItemsEntities(true, -1, -1);
    }

    public List<Items> findItemsEntities(int maxResults, int firstResult) {
        return findItemsEntities(false, maxResults, firstResult);
    }

    private List<Items> findItemsEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Items.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Items findItems(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Items.class, id);
        } finally {
            em.close();
        }
    }

    public int getItemsCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Items> rt = cq.from(Items.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
