/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package biblioteca.Beans;

import biblioteca.Beans.exceptions.NonexistentEntityException;
import biblioteca.Beans.exceptions.RollbackFailureException;
import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import biblioteca.entities.Items;
import biblioteca.entities.Prestamo;
import biblioteca.entities.Usuariobiblioteca;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.transaction.UserTransaction;

/**
 *
 * @author T14750
 */
public class PrestamoJpaController implements Serializable {

    public PrestamoJpaController(UserTransaction utx, EntityManagerFactory emf) {
        this.utx = utx;
        this.emf = emf;
    }
    private UserTransaction utx = null;
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Prestamo prestamo) throws RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Items codItem = prestamo.getCodItem();
            if (codItem != null) {
                codItem = em.getReference(codItem.getClass(), codItem.getIdItems());
                prestamo.setCodItem(codItem);
            }
            Usuariobiblioteca tarjetaUsuario = prestamo.getTarjetaUsuario();
            if (tarjetaUsuario != null) {
                tarjetaUsuario = em.getReference(tarjetaUsuario.getClass(), tarjetaUsuario.getTarjetaBiblioteca());
                prestamo.setTarjetaUsuario(tarjetaUsuario);
            }
            em.persist(prestamo);
            if (codItem != null) {
                codItem.getPrestamoList().add(prestamo);
                codItem = em.merge(codItem);
            }
            if (tarjetaUsuario != null) {
                tarjetaUsuario.getPrestamoList().add(prestamo);
                tarjetaUsuario = em.merge(tarjetaUsuario);
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Prestamo prestamo) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Prestamo persistentPrestamo = em.find(Prestamo.class, prestamo.getIdprestamo());
            Items codItemOld = persistentPrestamo.getCodItem();
            Items codItemNew = prestamo.getCodItem();
            Usuariobiblioteca tarjetaUsuarioOld = persistentPrestamo.getTarjetaUsuario();
            Usuariobiblioteca tarjetaUsuarioNew = prestamo.getTarjetaUsuario();
            if (codItemNew != null) {
                codItemNew = em.getReference(codItemNew.getClass(), codItemNew.getIdItems());
                prestamo.setCodItem(codItemNew);
            }
            if (tarjetaUsuarioNew != null) {
                tarjetaUsuarioNew = em.getReference(tarjetaUsuarioNew.getClass(), tarjetaUsuarioNew.getTarjetaBiblioteca());
                prestamo.setTarjetaUsuario(tarjetaUsuarioNew);
            }
            prestamo = em.merge(prestamo);
            if (codItemOld != null && !codItemOld.equals(codItemNew)) {
                codItemOld.getPrestamoList().remove(prestamo);
                codItemOld = em.merge(codItemOld);
            }
            if (codItemNew != null && !codItemNew.equals(codItemOld)) {
                codItemNew.getPrestamoList().add(prestamo);
                codItemNew = em.merge(codItemNew);
            }
            if (tarjetaUsuarioOld != null && !tarjetaUsuarioOld.equals(tarjetaUsuarioNew)) {
                tarjetaUsuarioOld.getPrestamoList().remove(prestamo);
                tarjetaUsuarioOld = em.merge(tarjetaUsuarioOld);
            }
            if (tarjetaUsuarioNew != null && !tarjetaUsuarioNew.equals(tarjetaUsuarioOld)) {
                tarjetaUsuarioNew.getPrestamoList().add(prestamo);
                tarjetaUsuarioNew = em.merge(tarjetaUsuarioNew);
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = prestamo.getIdprestamo();
                if (findPrestamo(id) == null) {
                    throw new NonexistentEntityException("The prestamo with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Prestamo prestamo;
            try {
                prestamo = em.getReference(Prestamo.class, id);
                prestamo.getIdprestamo();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The prestamo with id " + id + " no longer exists.", enfe);
            }
            Items codItem = prestamo.getCodItem();
            if (codItem != null) {
                codItem.getPrestamoList().remove(prestamo);
                codItem = em.merge(codItem);
            }
            Usuariobiblioteca tarjetaUsuario = prestamo.getTarjetaUsuario();
            if (tarjetaUsuario != null) {
                tarjetaUsuario.getPrestamoList().remove(prestamo);
                tarjetaUsuario = em.merge(tarjetaUsuario);
            }
            em.remove(prestamo);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Prestamo> findPrestamoEntities() {
        return findPrestamoEntities(true, -1, -1);
    }

    public List<Prestamo> findPrestamoEntities(int maxResults, int firstResult) {
        return findPrestamoEntities(false, maxResults, firstResult);
    }

    private List<Prestamo> findPrestamoEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Prestamo.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Prestamo findPrestamo(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Prestamo.class, id);
        } finally {
            em.close();
        }
    }

    public int getPrestamoCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Prestamo> rt = cq.from(Prestamo.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
