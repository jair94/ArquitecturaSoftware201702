/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package biblioteca.Beans;

import biblioteca.Beans.exceptions.IllegalOrphanException;
import biblioteca.Beans.exceptions.NonexistentEntityException;
import biblioteca.Beans.exceptions.RollbackFailureException;
import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import biblioteca.entities.Multas;
import java.util.ArrayList;
import java.util.List;
import biblioteca.entities.Prestamo;
import biblioteca.entities.Reservas;
import biblioteca.entities.Usuariobiblioteca;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.transaction.UserTransaction;

/**
 *
 * @author T14750
 */
public class UsuariobibliotecaJpaController implements Serializable {

    public UsuariobibliotecaJpaController(UserTransaction utx, EntityManagerFactory emf) {
        this.utx = utx;
        this.emf = emf;
    }
    private UserTransaction utx = null;
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Usuariobiblioteca usuariobiblioteca) throws RollbackFailureException, Exception {
        if (usuariobiblioteca.getMultasList() == null) {
            usuariobiblioteca.setMultasList(new ArrayList<Multas>());
        }
        if (usuariobiblioteca.getPrestamoList() == null) {
            usuariobiblioteca.setPrestamoList(new ArrayList<Prestamo>());
        }
        if (usuariobiblioteca.getReservasList() == null) {
            usuariobiblioteca.setReservasList(new ArrayList<Reservas>());
        }
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            List<Multas> attachedMultasList = new ArrayList<Multas>();
            for (Multas multasListMultasToAttach : usuariobiblioteca.getMultasList()) {
                multasListMultasToAttach = em.getReference(multasListMultasToAttach.getClass(), multasListMultasToAttach.getMultasPK());
                attachedMultasList.add(multasListMultasToAttach);
            }
            usuariobiblioteca.setMultasList(attachedMultasList);
            List<Prestamo> attachedPrestamoList = new ArrayList<Prestamo>();
            for (Prestamo prestamoListPrestamoToAttach : usuariobiblioteca.getPrestamoList()) {
                prestamoListPrestamoToAttach = em.getReference(prestamoListPrestamoToAttach.getClass(), prestamoListPrestamoToAttach.getIdprestamo());
                attachedPrestamoList.add(prestamoListPrestamoToAttach);
            }
            usuariobiblioteca.setPrestamoList(attachedPrestamoList);
            List<Reservas> attachedReservasList = new ArrayList<Reservas>();
            for (Reservas reservasListReservasToAttach : usuariobiblioteca.getReservasList()) {
                reservasListReservasToAttach = em.getReference(reservasListReservasToAttach.getClass(), reservasListReservasToAttach.getIdReservas());
                attachedReservasList.add(reservasListReservasToAttach);
            }
            usuariobiblioteca.setReservasList(attachedReservasList);
            em.persist(usuariobiblioteca);
            for (Multas multasListMultas : usuariobiblioteca.getMultasList()) {
                Usuariobiblioteca oldUsuariobibliotecaOfMultasListMultas = multasListMultas.getUsuariobiblioteca();
                multasListMultas.setUsuariobiblioteca(usuariobiblioteca);
                multasListMultas = em.merge(multasListMultas);
                if (oldUsuariobibliotecaOfMultasListMultas != null) {
                    oldUsuariobibliotecaOfMultasListMultas.getMultasList().remove(multasListMultas);
                    oldUsuariobibliotecaOfMultasListMultas = em.merge(oldUsuariobibliotecaOfMultasListMultas);
                }
            }
            for (Prestamo prestamoListPrestamo : usuariobiblioteca.getPrestamoList()) {
                Usuariobiblioteca oldTarjetaUsuarioOfPrestamoListPrestamo = prestamoListPrestamo.getTarjetaUsuario();
                prestamoListPrestamo.setTarjetaUsuario(usuariobiblioteca);
                prestamoListPrestamo = em.merge(prestamoListPrestamo);
                if (oldTarjetaUsuarioOfPrestamoListPrestamo != null) {
                    oldTarjetaUsuarioOfPrestamoListPrestamo.getPrestamoList().remove(prestamoListPrestamo);
                    oldTarjetaUsuarioOfPrestamoListPrestamo = em.merge(oldTarjetaUsuarioOfPrestamoListPrestamo);
                }
            }
            for (Reservas reservasListReservas : usuariobiblioteca.getReservasList()) {
                Usuariobiblioteca oldTarjetaUsuarioOfReservasListReservas = reservasListReservas.getTarjetaUsuario();
                reservasListReservas.setTarjetaUsuario(usuariobiblioteca);
                reservasListReservas = em.merge(reservasListReservas);
                if (oldTarjetaUsuarioOfReservasListReservas != null) {
                    oldTarjetaUsuarioOfReservasListReservas.getReservasList().remove(reservasListReservas);
                    oldTarjetaUsuarioOfReservasListReservas = em.merge(oldTarjetaUsuarioOfReservasListReservas);
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Usuariobiblioteca usuariobiblioteca) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Usuariobiblioteca persistentUsuariobiblioteca = em.find(Usuariobiblioteca.class, usuariobiblioteca.getTarjetaBiblioteca());
            List<Multas> multasListOld = persistentUsuariobiblioteca.getMultasList();
            List<Multas> multasListNew = usuariobiblioteca.getMultasList();
            List<Prestamo> prestamoListOld = persistentUsuariobiblioteca.getPrestamoList();
            List<Prestamo> prestamoListNew = usuariobiblioteca.getPrestamoList();
            List<Reservas> reservasListOld = persistentUsuariobiblioteca.getReservasList();
            List<Reservas> reservasListNew = usuariobiblioteca.getReservasList();
            List<String> illegalOrphanMessages = null;
            for (Multas multasListOldMultas : multasListOld) {
                if (!multasListNew.contains(multasListOldMultas)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain Multas " + multasListOldMultas + " since its usuariobiblioteca field is not nullable.");
                }
            }
            for (Prestamo prestamoListOldPrestamo : prestamoListOld) {
                if (!prestamoListNew.contains(prestamoListOldPrestamo)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain Prestamo " + prestamoListOldPrestamo + " since its tarjetaUsuario field is not nullable.");
                }
            }
            for (Reservas reservasListOldReservas : reservasListOld) {
                if (!reservasListNew.contains(reservasListOldReservas)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain Reservas " + reservasListOldReservas + " since its tarjetaUsuario field is not nullable.");
                }
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            List<Multas> attachedMultasListNew = new ArrayList<Multas>();
            for (Multas multasListNewMultasToAttach : multasListNew) {
                multasListNewMultasToAttach = em.getReference(multasListNewMultasToAttach.getClass(), multasListNewMultasToAttach.getMultasPK());
                attachedMultasListNew.add(multasListNewMultasToAttach);
            }
            multasListNew = attachedMultasListNew;
            usuariobiblioteca.setMultasList(multasListNew);
            List<Prestamo> attachedPrestamoListNew = new ArrayList<Prestamo>();
            for (Prestamo prestamoListNewPrestamoToAttach : prestamoListNew) {
                prestamoListNewPrestamoToAttach = em.getReference(prestamoListNewPrestamoToAttach.getClass(), prestamoListNewPrestamoToAttach.getIdprestamo());
                attachedPrestamoListNew.add(prestamoListNewPrestamoToAttach);
            }
            prestamoListNew = attachedPrestamoListNew;
            usuariobiblioteca.setPrestamoList(prestamoListNew);
            List<Reservas> attachedReservasListNew = new ArrayList<Reservas>();
            for (Reservas reservasListNewReservasToAttach : reservasListNew) {
                reservasListNewReservasToAttach = em.getReference(reservasListNewReservasToAttach.getClass(), reservasListNewReservasToAttach.getIdReservas());
                attachedReservasListNew.add(reservasListNewReservasToAttach);
            }
            reservasListNew = attachedReservasListNew;
            usuariobiblioteca.setReservasList(reservasListNew);
            usuariobiblioteca = em.merge(usuariobiblioteca);
            for (Multas multasListNewMultas : multasListNew) {
                if (!multasListOld.contains(multasListNewMultas)) {
                    Usuariobiblioteca oldUsuariobibliotecaOfMultasListNewMultas = multasListNewMultas.getUsuariobiblioteca();
                    multasListNewMultas.setUsuariobiblioteca(usuariobiblioteca);
                    multasListNewMultas = em.merge(multasListNewMultas);
                    if (oldUsuariobibliotecaOfMultasListNewMultas != null && !oldUsuariobibliotecaOfMultasListNewMultas.equals(usuariobiblioteca)) {
                        oldUsuariobibliotecaOfMultasListNewMultas.getMultasList().remove(multasListNewMultas);
                        oldUsuariobibliotecaOfMultasListNewMultas = em.merge(oldUsuariobibliotecaOfMultasListNewMultas);
                    }
                }
            }
            for (Prestamo prestamoListNewPrestamo : prestamoListNew) {
                if (!prestamoListOld.contains(prestamoListNewPrestamo)) {
                    Usuariobiblioteca oldTarjetaUsuarioOfPrestamoListNewPrestamo = prestamoListNewPrestamo.getTarjetaUsuario();
                    prestamoListNewPrestamo.setTarjetaUsuario(usuariobiblioteca);
                    prestamoListNewPrestamo = em.merge(prestamoListNewPrestamo);
                    if (oldTarjetaUsuarioOfPrestamoListNewPrestamo != null && !oldTarjetaUsuarioOfPrestamoListNewPrestamo.equals(usuariobiblioteca)) {
                        oldTarjetaUsuarioOfPrestamoListNewPrestamo.getPrestamoList().remove(prestamoListNewPrestamo);
                        oldTarjetaUsuarioOfPrestamoListNewPrestamo = em.merge(oldTarjetaUsuarioOfPrestamoListNewPrestamo);
                    }
                }
            }
            for (Reservas reservasListNewReservas : reservasListNew) {
                if (!reservasListOld.contains(reservasListNewReservas)) {
                    Usuariobiblioteca oldTarjetaUsuarioOfReservasListNewReservas = reservasListNewReservas.getTarjetaUsuario();
                    reservasListNewReservas.setTarjetaUsuario(usuariobiblioteca);
                    reservasListNewReservas = em.merge(reservasListNewReservas);
                    if (oldTarjetaUsuarioOfReservasListNewReservas != null && !oldTarjetaUsuarioOfReservasListNewReservas.equals(usuariobiblioteca)) {
                        oldTarjetaUsuarioOfReservasListNewReservas.getReservasList().remove(reservasListNewReservas);
                        oldTarjetaUsuarioOfReservasListNewReservas = em.merge(oldTarjetaUsuarioOfReservasListNewReservas);
                    }
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = usuariobiblioteca.getTarjetaBiblioteca();
                if (findUsuariobiblioteca(id) == null) {
                    throw new NonexistentEntityException("The usuariobiblioteca with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Usuariobiblioteca usuariobiblioteca;
            try {
                usuariobiblioteca = em.getReference(Usuariobiblioteca.class, id);
                usuariobiblioteca.getTarjetaBiblioteca();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The usuariobiblioteca with id " + id + " no longer exists.", enfe);
            }
            List<String> illegalOrphanMessages = null;
            List<Multas> multasListOrphanCheck = usuariobiblioteca.getMultasList();
            for (Multas multasListOrphanCheckMultas : multasListOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Usuariobiblioteca (" + usuariobiblioteca + ") cannot be destroyed since the Multas " + multasListOrphanCheckMultas + " in its multasList field has a non-nullable usuariobiblioteca field.");
            }
            List<Prestamo> prestamoListOrphanCheck = usuariobiblioteca.getPrestamoList();
            for (Prestamo prestamoListOrphanCheckPrestamo : prestamoListOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Usuariobiblioteca (" + usuariobiblioteca + ") cannot be destroyed since the Prestamo " + prestamoListOrphanCheckPrestamo + " in its prestamoList field has a non-nullable tarjetaUsuario field.");
            }
            List<Reservas> reservasListOrphanCheck = usuariobiblioteca.getReservasList();
            for (Reservas reservasListOrphanCheckReservas : reservasListOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Usuariobiblioteca (" + usuariobiblioteca + ") cannot be destroyed since the Reservas " + reservasListOrphanCheckReservas + " in its reservasList field has a non-nullable tarjetaUsuario field.");
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            em.remove(usuariobiblioteca);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Usuariobiblioteca> findUsuariobibliotecaEntities() {
        return findUsuariobibliotecaEntities(true, -1, -1);
    }

    public List<Usuariobiblioteca> findUsuariobibliotecaEntities(int maxResults, int firstResult) {
        return findUsuariobibliotecaEntities(false, maxResults, firstResult);
    }

    private List<Usuariobiblioteca> findUsuariobibliotecaEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Usuariobiblioteca.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Usuariobiblioteca findUsuariobiblioteca(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Usuariobiblioteca.class, id);
        } finally {
            em.close();
        }
    }

    public int getUsuariobibliotecaCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Usuariobiblioteca> rt = cq.from(Usuariobiblioteca.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
